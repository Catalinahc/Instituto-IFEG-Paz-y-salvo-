import React from 'react';

const ExpenseSummary = ({ expenses }) => {
  const total = expenses.reduce((sum, expense) => sum + expense.amount, 0);

  return (
    <div className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4 rounded-lg shadow-lg mb-6">
      <h2 className="text-lg font-semibold mb-2">Resumen de Gastos</h2>
      <div className="flex justify-between items-center">
        <span>Total:</span>
        <span className="text-2xl font-bold">${total.toFixed(2)}</span>
      </div>
    </div>
  );
};

export default ExpenseSummary;

// DONE