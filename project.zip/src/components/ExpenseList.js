import React from 'react';
import ExpenseItem from './ExpenseItem';

const ExpenseList = ({ expenses, onDelete }) => {
  return (
    <div className="mt-6">
      <h2 className="text-xl font-bold text-gray-800 mb-4">Tus Gastos</h2>
      {expenses.length === 0 ? (
        <p className="text-gray-500 text-center py-4">No hay gastos registrados</p>
      ) : (
        <div className="space-y-2">
          {expenses.map((expense) => (
            <ExpenseItem key={expense.id} expense={expense} onDelete={onDelete} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ExpenseList;