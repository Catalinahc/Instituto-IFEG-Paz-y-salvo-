const expenses = [
  {
    id: 1,
    title: "Café",
    amount: 3.50,
    category: "Comida",
    date: "2023-05-15"
  },
  {
    id: 2,
    title: "Transporte",
    amount: 1.50,
    category: "Transporte",
    date: "2023-05-16"
  },
  {
    id: 3,
    title: "Cine",
    amount: 8.00,
    category: "Entretenimiento",
    date: "2023-05-17"
  }
];

export default expenses;